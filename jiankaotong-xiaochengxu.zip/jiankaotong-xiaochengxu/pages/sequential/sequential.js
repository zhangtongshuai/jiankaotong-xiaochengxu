const app = getApp()
var time = 0;
var touchDot = 0;//触摸时的原点
var interval = "";
var flag_hd = true;
Page({
  data: {
    flag: true,
    item:[
      { id: '0', value: '施工员', checked: 'true', check_num: 1 },
      { id: '1', value: '质量员', check_num: 0 },
      { id: '2', value: '机械员', check_num: 0 },
      { id: '3', value: '资料员', check_num: 0 },
      { id: '4', value: '材料员', check_num: 0 },
      { id: '5', value: '劳务员', check_num: 0 },
    ],
  },
  onLoad: function () {
    var that = this
  },
  onShow: function () {
    flag_hd = true;    //重新进入页面之后，可以再次执行滑动切换页面代码
    clearInterval(interval); // 清除setInterval
    time = 0;
  },
  // 遮罩层显示
  show: function () {
    this.setData({ flag: false })
  },
  // 遮罩层隐藏
  conceal: function () {
    this.setData({ flag: true })
  },
  // 触摸开始事件
  touchStart: function (e) {
    touchDot = e.touches[0].pageX; // 获取触摸时的原点
    // 使用js计时器记录时间    
    interval = setInterval(function () {
      time++;
    }, 100);
  },
  // 触摸结束事件
  touchEnd: function (e) {
    var touchMove = e.changedTouches[0].pageX;
    // 向左滑动   
    if (touchMove - touchDot <= -40 && time < 10 && flag_hd == true) {
      flag_hd = false;
      //执行切换页面的方法
      console.log("向右滑动");
      console.log(time)
      console.log(touchDot)
      console.log(flag_hd)
      console.log()
      flag_hd = true;
    }
    // 向右滑动   
    if (touchMove - touchDot >= 40 && time < 10 && flag_hd == true) {
      flag_hd = false;
      //执行切换页面的方法
      console.log("向左滑动");


      flag_hd = true;
    }
    clearInterval(interval); // 清除setInterval
    time = 0;
  },
  //分享
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '简直走别拐弯', // 转发后 所显示的title
      path: '/pages/group/index', // 相对的路径
      success: (res) => {    // 成功后要做的事情
        console.log(res.shareTickets[0])
        // console.log

        wx.getShareInfo({
          shareTicket: res.shareTickets[0],
          success: (res) => {
            that.setData({
              isShow: true
            })
            console.log(that.setData.isShow)
          },
          fail: function (res) { console.log(res) },
          complete: function (res) { console.log(res) }
        })
      },
      fail: function (res) {
        // 分享失败
        console.log(res)
      }
    }
  },
  //收藏
  isCollect:function(e){
    wx.showModal({
      title: '确定要收藏本题',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        }
      }
    })
  }
})
