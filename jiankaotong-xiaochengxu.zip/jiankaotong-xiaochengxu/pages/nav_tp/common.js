var navbar = [
  {
    name: '六大员',
    url: "/pages/index/index"
  },
  {
    name: "安全员",
    url: "/pages/safe/safe"
  },
  {
    name: "我的",
    url: "/pages/myinfo/myinfo"
  }
]
//哎呀，这里之前写差一个s，然后一直拿不到数据，苦死我，广大网友别学我
module.exports = {
  navbar: navbar
}