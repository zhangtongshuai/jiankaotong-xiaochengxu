const app = getApp()
Page({
  data: {

  },
  onLoad: function () {

  },
  analog_result:function(e){
    wx.navigateTo({
      url: '../analog_result/analog_result',
    })
  }
})