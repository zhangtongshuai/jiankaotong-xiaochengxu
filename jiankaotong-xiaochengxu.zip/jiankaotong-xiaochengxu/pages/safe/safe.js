const app = getApp()
Page({
  data: {
    
  },
  onLoad: function () {
  
  },
  certificate_type: function (e) {
    wx.navigateTo({
      url: '../city_status/city_status',
    })
  },
  special_info: function (e) {
    wx.navigateTo({
      url: '../special/special',
    })
  },
  my_questions: function (e) {
    wx.navigateTo({
      url: '../questions/questions',
    })
  },
  my_collect: function (e) {
    wx.navigateTo({
      url: '../collect/collect',
    })
  },
  sequential_practice: function (e) {
    wx.navigateTo({
      url: '../sequential/sequential',
    })
  },
  simulation_info: function (e) {
    wx.navigateTo({
      url: '../simulation/simulation',
    })
  }
})
