const app = getApp()
Page({
  data: {
    
  },
  onLoad: function () {

  },
  my_questions:function(e){
    wx.navigateTo({
      url: '../questions/questions',
    })
  },
  my_collect:function(e){
    wx.navigateTo({
      url: '../collect/collect',
    })
  }
})