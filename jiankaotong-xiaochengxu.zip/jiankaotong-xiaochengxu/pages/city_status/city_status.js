const app = getApp()
Page({
  data: {
    items: [
      { name: '0', value: '施工员', checked: 'true',check_num: 1 },
      { name: '1', value: '质量员', check_num: 0 },
      { name: '2', value: '机械员', check_num: 0 },
      { name: '3', value: '资料员', check_num: 0 },
      { name: '4', value: '材料员', check_num: 0 },
      { name: '5', value: '劳务员', check_num: 0 },
    ]
  },
  onLoad: function () {
    
  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
  },
  certificate_list_tap:function(e){
    console.log(e)
    var num = e.currentTarget.dataset.check;
    var now_check_num = 'items[' + num + '].check_num';
    this.setData({
      'items[0].check_num': 0,
      'items[1].check_num': 0,
      'items[2].check_num': 0,
      'items[3].check_num': 0,
      'items[4].check_num': 0,
      'items[5].check_num': 0,
      [now_check_num]: 1,
    })
  }
})